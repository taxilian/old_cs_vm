Richard Bateman
Virtual Machine

All commands should be supported; BYT values are stored as 4 byte ints just like a normal int, but that shouldn't be visible when running the VM.

This program requires boost to be installed in order to build.

Assembly file: proj1.asm
VM executable: vm.exe
Run: "vm.exe project1.asm"

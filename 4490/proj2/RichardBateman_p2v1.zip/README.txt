Richard Bateman

Virtual Machine



All commands should be supported;



This program requires boost to be installed in order to build.



Assembly file: proj2.asm


VM executable: vm.exe_ (rename to vm.exe)


Run: "vm.exe proj2.asm"

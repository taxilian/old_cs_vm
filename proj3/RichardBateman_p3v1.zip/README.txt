Richard Bateman

Virtual Machine

All commands should be supported;

This program requires boost to be installed in order to build.

Assembly file: proj3.asm

VM executable: vm.exe_ (rename to vm.exe)

Run: "vm.exe proj3.asm"
